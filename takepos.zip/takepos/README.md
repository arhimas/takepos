# TAKEPOS

## Features
Add a Touch Screen POS (Point Of Sale) to your ERP.

<!--
![Screenshot takepos](img/screenshot_takepos.png?raw=true "TakePos"){imgmd}
-->

